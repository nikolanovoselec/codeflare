# @narumitw/pi-goal

## 0.55.1

### Patch Changes

- Updated dependencies [cf7b63d]
  - @narumitw/pi-tui-kit@0.70.0

## 0.55.0

### Minor Changes

- 2b3d1d2: Add default-off `retryUsageLimits` recovery for recognized provider quota errors. When enabled, Goal retains its identity and workflow ownership in active waiting, then schedules recovery through the settled-idle dispatcher using an applicable public reset hint or a 15-minute fallback. No usage service is required.
  
  Only work-free, directly quota-rejected scheduled recovery requests are exempt from automatic-work and no-progress counters. Provider-reported token usage always counts; successful work, partial work, original requests, and native retries retain existing accounting.
  
  Recovery can make paid requests and wait indefinitely for billing, credit, or entitlement action. Disabling it cancels pending quota recovery; enabling it does not restart an already stopped Goal. Native retry and ordinary external-wait policies remain unchanged.

## 0.54.17

### Patch Changes

- 5f92841: Use Pi's native provider retry and context-overflow classifiers without Goal-owned retry patterns or usage/authentication vetoes. Keep unclassified assistant errors in deadline-free active waiting without adding a retry, including premature stream closures, invalid requests, authentication failures, and empty error messages. Preserve Goal identity and managed-run ownership until wake, completion, or explicit cancellation; permanent failures can wait indefinitely. Select final recognized usage limits after native recovery, and pause when Pi reports a cancelled run or automatic compaction. Preserve active waiting after native retry-only cancellation; use `/goal pause` for an explicit pause. Keep safety limits and automatic accounting through native truncated-response compaction. Preserve pending errors across threshold compaction and block failed native compaction recovery.

## 0.54.16

### Patch Changes

- 5c09977: Treat prematurely closed connections and prematurely ended streams as retryable Goal interruptions, including proxy-wrapped HTTP 400 errors. Keep the Goal active through the existing provider-recovery wait instead of marking it blocked.
- 6c843a2: Store independent Goal state snapshots in session history so later accounting and waiting-state updates do not change earlier entries. Keep in-memory history aligned with JSONL records and preserve append-time state during deferred writes and branch restoration.
- Updated dependencies [4f79c28]
  - @narumitw/pi-tui-kit@0.69.1

## 0.54.15

### Patch Changes

- e484010: Include the existing package-root CHANGELOG.md in extension tarballs so Pi can show native update notices. Keep Changesets version headings and Pi's first-observation and collapseChangelog behavior unchanged.
- Updated dependencies [54f2700]
- Updated dependencies [6c76ef1]
  - @narumitw/pi-tui-kit@0.69.0

## 0.54.14

### Patch Changes

- 9d3e0d7: Prevent passive UI timers from keeping Node alive while preserving status expiry, settings reloads, paste handling, and cleanup.
- Updated dependencies [9d3e0d7]
  - @narumitw/pi-tui-kit@0.68.1

## 0.54.13

### Patch Changes

- 41a422d: Publish the Goal contract when a Goal is started, resumed, or edited while the agent is busy, so it is persisted once at the turn boundary instead of being appended at the tail of every request until the current run ends.
- 5bc5d7f: Deduplicate Goal contracts that are queued during run startup or another busy publication. Preserve ordered active/inactive revisions and restore contracts after compaction without changing automatic continuation prompts or existing request prefixes.

## 0.54.12

### Patch Changes

- fed7bfb: Handle Pi custom-message run starts without consuming queued file quotes, clearing ready plans, or applying user-prompt Goal ownership logic.

## 0.54.11

### Patch Changes

- 42ee79c: Show a Goal contract that Pi persisted after newer output, because it was sent while the agent was streaming, at the turn boundary where it was sent. Mid-run compaction now keeps the restored contract's request position once the persisted copy arrives, so the next request reuses the retained prefix.
- Updated dependencies [178e2e4]
  - @narumitw/pi-tui-kit@0.65.3

## 0.54.10

### Patch Changes

- 847a17f: Append missing Goal contracts after retained history following compaction so transient restoration and immediately persisted contracts use the same message position, preserving the retained request prefix. Persist missing inactive contracts at the compaction boundary instead of repeatedly restoring them at a moving tail.

## 0.54.9

### Patch Changes

- c40dd4c: Preserve `goal_wait` deadline wake-ups after backward wall-clock corrections by re-arming early timers against their original absolute deadline. Apply the same protection to the bounded deadline-delivery retry while preserving cancellation and settled-idle continuation gates.

## 0.54.8

### Patch Changes

- 8abd5b7: Keep generated extension runtime graphs inside Pi's Jiti-loaded TypeScript path to avoid duplicate peer-runtime evaluation during startup. Add measured generated runtimes for Context Management, Herdr, and TypeSafe Search.

## 0.54.7

### Patch Changes

- 67a3049: Adapt provider, transcript, usage, deferred-tool, and telemetry behavior to Pi's current runtime contracts, including accurate cache-warming accounting and exclusion from ordinary generation traces.

## 0.54.6

### Patch Changes

- e894777: Treat premature provider stream endings, such as `Upstream stream ended before terminal chunk`, as retryable provider errors instead of terminal agent failures.

## 0.54.5

### Patch Changes

- ea85bd8: Ignore stale extension contexts after session replacement or reload so detached prompt emits, delayed goal timers, and in-flight /goal commands cannot surface extension errors or crash Pi.

## 0.54.4

### Patch Changes

- aca0c7d: Render accepted `goal_complete` summaries as sanitized Markdown in the TUI.

## 0.54.3

### Patch Changes

- Updated dependencies [40182e5]
  - @narumitw/pi-tui-kit@0.59.0

## 0.54.2

### Patch Changes

- e0c0766: Persist the real `goal_blocked` result before publishing the inactive Goal contract.

## 0.54.1

### Patch Changes

- 35e5ee7: Persist the real `goal_complete` result before publishing the inactive Goal contract.
- Updated dependencies [663f72a]
  - @narumitw/pi-tui-kit@0.58.2

## 0.54.0

### Minor Changes

- b59cdbc: Remove the `toolVisibility` setting and keep Goal helper schemas stable from startup.
  Retired settings keys are ignored and preserved, while restrictive external tool policies now reject or pause Goal work without being widened.

## 0.53.3

### Patch Changes

- 21f96d0: Keep Goals recoverable in deadline-free waiting after transient provider retries are exhausted so a later follow-up can continue, complete, or wait again with the same Goal ID.
- 22ae047: Preserve retained conversation cache prefixes with append-only superseding Goal contracts, atomic handoff-boundary persistence, and current-state restoration after lifecycle transitions and compaction.

## 0.53.2

### Patch Changes

- 3346683: Publish generated lazy chunks at the JavaScript paths referenced by each extension runtime so deferred menus and implementations load correctly through Pi's Jiti loader.
- Updated dependencies [b9eba3a]
  - @narumitw/pi-tui-kit@0.58.0

## 0.53.1

### Patch Changes

- 4098679: Keep token-budget accounting out of leading system instructions and preserve the post-activation provider request prefix across Goal continuation and wait resume.

## 0.53.0

### Minor Changes

- b23a1bc: Coordinate automatically executable Goals through Workflow Mutex Protocol v1 and stop Goal-owned work immediately at terminal limits.

## 0.52.3

### Patch Changes

- Updated dependencies [6574232]
- Updated dependencies [cddc265]
  - @narumitw/pi-tui-kit@0.57.0

## 0.52.2

### Patch Changes

- 30bc076: Load each extension from a generated TypeScript runtime to reduce Jiti package startup work while preserving existing first-use boundaries.

## 0.52.1

### Patch Changes

- Updated dependencies [8bead31]
  - @narumitw/pi-tui-kit@0.56.0

## 0.52.0

### Minor Changes

- 5269d4b: Remove the experimental ordered-goal queue and guide affected users to reprioritize with `/goal edit`.

### Patch Changes

- Updated dependencies [3176172]
  - @narumitw/pi-tui-kit@0.55.0

## 0.51.0

### Minor Changes

- ef4680b: Start `goal_complete`, `goal_blocked`, and `goal_wait` inactive by default until the first Goal activation or unfinished-goal restore.

## 0.50.0

### Minor Changes

- db4b576: Add `goal_wait` so active Goals can wait quietly for external messages or an optional bounded deadline without creating automatic continuation loops.

### Patch Changes

- d105b85: Clamp sub-ten-second `goal_wait` deadlines and report their effective delay to prevent rapid automatic wake loops.

## 0.49.7

### Patch Changes

- fa9c938: Reduce idle startup imports by loading Goal presentation, Chat networking and UI, and Sync operation-specific modules only when their routes require them.

## 0.49.6

### Patch Changes

- 6f98395: Sanitize terminal-rendered Goal text, bound terminal-tool inputs and outputs, report malformed commands in headless modes, and keep runtime smoke coverage on public Pi APIs.
