import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { spawnSync, type SpawnSyncOptionsWithStringEncoding } from "node:child_process";
import { existsSync, realpathSync } from "node:fs";
import { homedir, platform } from "node:os";
import { dirname, extname, isAbsolute, join, relative, resolve, sep } from "node:path";
import stripJsonComments from "strip-json-comments";
import type { McpConfig, McpToolAnnotations, ServerEntry } from "./types.ts";

export function stripUtf8Bom(raw: string): string {
  return raw.charCodeAt(0) === 0xfeff ? raw.slice(1) : raw;
}

export function parseJsonWithComments(raw: string): unknown {
  return JSON.parse(stripJsonComments(stripUtf8Bom(raw), { trailingCommas: true }));
}

/** Resolve a candidate only when its real path stays within the real root. */
export function resolveRealContainedPath(root: string, candidate: string, allowMissing = false): string | null {
  const contained = resolveContainedPath(root, candidate);
  if (!contained) return null;
  const canonical = (path: string): string => {
    let existing = path;
    while (allowMissing && !existsSync(existing)) {
      const parent = dirname(existing);
      if (parent === existing) throw new Error("No existing path ancestor");
      existing = parent;
    }
    return resolve(realpathSync(existing), relative(existing, path));
  };
  try {
    return resolveContainedPath(canonical(root), canonical(contained));
  } catch {
    return null;
  }
}

export function resolveContainedPath(root: string, candidate: string): string | null {
  const resolved = resolve(root, candidate);
  const rel = relative(root, resolved);
  return rel === "" || (!rel.startsWith("..") && !rel.startsWith(sep) && !isAbsolute(rel)) ? resolved : null;
}

export function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value) ?? "undefined";
  if (Array.isArray(value)) {
    return `[${value.map(item => stableStringify(item)).join(",")}]`;
  }
  const object = value as Record<string, unknown>;
  return `{${Object.keys(object).sort().map(key => `${JSON.stringify(key)}:${stableStringify(object[key])}`).join(",")}}`;
}

async function execOpen(pi: ExtensionAPI, target: string, browser?: string, signal?: AbortSignal) {
  const os = platform();

  if (os === "darwin") {
    if (browser) {
      // An absolute executable path (e.g. from $BROWSER) names a launcher
      // binary. App bundles still go through `open -a`, which handles them.
      return isAbsolute(browser) && extname(browser).toLowerCase() !== ".app"
        ? pi.exec(browser, [target], signal ? { signal } : {})
        : pi.exec("open", ["-a", browser, target], signal ? { signal } : {});
    }
    return pi.exec("open", [target], signal ? { signal } : {});
  }
  if (os === "win32") {
    return browser
      ? pi.exec("cmd", ["/c", "start", "", browser, target], signal ? { signal } : {})
      : pi.exec("cmd", ["/c", "start", "", target], signal ? { signal } : {});
  }
  return browser
    ? pi.exec(browser, [target], signal ? { signal } : {})
    : pi.exec("xdg-open", [target], signal ? { signal } : {});
}

export async function openUrl(pi: ExtensionAPI, url: string, browser?: string, signal?: AbortSignal): Promise<void> {
  const result = await execOpen(pi, url, browser, signal);
  if (result.code !== 0) {
    throw new Error(result.stderr || `Failed to open browser (exit code ${result.code})`);
  }
}

export async function openPath(pi: ExtensionAPI, targetPath: string): Promise<void> {
  const result = await execOpen(pi, targetPath);
  if (result.code !== 0) {
    throw new Error(result.stderr || `Failed to open path (exit code ${result.code})`);
  }
}

export async function parallelLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>
): Promise<R[]> {
  const results: R[] = [];
  const iterator = items.entries();

  async function worker() {
    while (true) {
      const next = iterator.next();
      if (next.done) return;
      const [index, item] = next.value;
      results[index] = await fn(item);
    }
  }

  const workers = Array(Math.min(limit, items.length)).fill(null).map(() => worker());
  await Promise.all(workers);
  return results;
}

export function getConfigPathFromArgv(): string | undefined {
  let configPath: string | undefined;
  for (let index = 2; index < process.argv.length; index++) {
    const arg = process.argv[index];
    if (arg === undefined) continue;
    if (arg === "--") break;

    if (arg === "--mcp-config") {
      const value = process.argv[index + 1];
      if (value !== undefined && !value.startsWith("-") && !value.startsWith("@")) {
        configPath = value;
        index++;
      } else {
        configPath = undefined;
      }
      continue;
    }

    if (arg.startsWith("--mcp-config=")) {
      configPath = arg.slice("--mcp-config=".length);
    }
  }
  return configPath;
}

export function interpolateEnvVars(value: string): string;
export function interpolateEnvVars(value: string, environment: NodeJS.ProcessEnv): string;
export function interpolateEnvVars(value: string, environment: NodeJS.ProcessEnv = process.env): string {
  return value
    .replace(/\$\{(\w+)\}/g, (_, name) => environment[name] ?? "")
    .replace(/\$env:(\w+)/g, (_, name) => environment[name] ?? "")
    .replace(/\{env:(\w+)\}/g, (_, name) => environment[name] ?? "");
}

export function getMissingEnvVars(value: string, environment: NodeJS.ProcessEnv = process.env): string[] {
  const missing = new Set<string>();
  for (const match of value.matchAll(/\$\{(\w+)\}|\$env:(\w+)|\{env:(\w+)\}/g)) {
    const name = match[1] ?? match[2] ?? match[3];
    if (name && environment[name] === undefined) {
      missing.add(name);
    }
  }
  return [...missing];
}

export function toStringRecord(value: unknown): Record<string, string> | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;

  const result: Record<string, string> = {};
  for (const [key, entry] of Object.entries(value)) {
    if (typeof entry === "string") result[key] = entry;
  }
  return Object.keys(result).length > 0 ? result : undefined;
}

function interpolateSecretExpression(value: string, environment: NodeJS.ProcessEnv): string {
  if (value.startsWith("!!")) return interpolateEnvVars(value.slice(1), environment);
  return value.startsWith("!") ? value : interpolateEnvVars(value, environment);
}

export function interpolateEnvRecord(values: Record<string, string> | undefined, environment: NodeJS.ProcessEnv = process.env): Record<string, string> | undefined {
  if (!values) return undefined;

  return Object.fromEntries(Object.entries(values).map(([key, value]) => [
    key,
    interpolateSecretExpression(value, environment),
  ]));
}

const COMMAND_SECRET_TIMEOUT_MS = 10_000;
const COMMAND_SECRET_MAX_OUTPUT_BYTES = 1024 * 1024;

let windowsCommandBash: string | null | undefined;

function isLegacyWslBash(path: string): boolean {
  return /^[a-z]:\\windows\\(?:system32|sysnative)\\bash\.exe$/.test(path.replace(/\//g, "\\").toLowerCase());
}

function findWindowsBash(): string | null {
  const installs = [process.env.ProgramFiles, process.env["ProgramFiles(x86)"]]
    .filter((dir): dir is string => Boolean(dir))
    .map(dir => `${dir}\\Git\\bin\\bash.exe`);
  const found = installs.find(path => existsSync(path));
  if (found) return found;
  try {
    const result = spawnSync("where", ["bash.exe"], { encoding: "utf8", timeout: 5000, windowsHide: true });
    if (result.status !== 0 || !result.stdout) return null;
    return result.stdout.split(/\r?\n/)
      .map(line => line.trim())
      .find(path => path && !isLegacyWslBash(path) && existsSync(path)) ?? null;
  } catch {
    return null;
  }
}

/**
 * On Windows, the bash used to run `!command` values: Git Bash in its standard
 * install locations, then bash.exe on PATH (skipping the legacy WSL launcher),
 * as Pi does. Undefined elsewhere or when none is found, so callers keep the
 * platform default shell.
 */
export function getWindowsCommandBash(): string | undefined {
  if (process.platform !== "win32") return undefined;
  if (windowsCommandBash === undefined) windowsCommandBash = findWindowsBash();
  return windowsCommandBash ?? undefined;
}

/** Resolve a secret value, executing only a single leading `!` command marker. */
export function resolveCommandSecret(value: string, context: string): string;
export function resolveCommandSecret(value: undefined, context: string): undefined;
export function resolveCommandSecret(value: string | undefined, context: string): string | undefined;
export function resolveCommandSecret(value: string | undefined, context: string): string | undefined {
  if (value === undefined) return undefined;
  if (value.startsWith("!!")) return interpolateEnvVars(value.slice(1));
  if (!value.startsWith("!")) return interpolateEnvVars(value);

  const options: SpawnSyncOptionsWithStringEncoding = {
    encoding: "utf8",
    timeout: COMMAND_SECRET_TIMEOUT_MS,
    maxBuffer: COMMAND_SECRET_MAX_OUTPUT_BYTES,
    stdio: ["ignore", "pipe", "ignore"],
    windowsHide: true,
  };
  const bash = getWindowsCommandBash();
  const result = bash === undefined
    ? spawnSync(value.slice(1), { ...options, shell: true })
    : spawnSync(bash, ["-c", value.slice(1)], { ...options, shell: false });
  if (result.error) {
    const code = (result.error as NodeJS.ErrnoException).code;
    const reason = code === "ETIMEDOUT"
      ? "command timed out after 10 seconds"
      : code === "ENOBUFS"
        ? "command output exceeded 1 MiB"
        : "command failed to start";
    throw new Error(`Failed to resolve ${context}: ${reason}`);
  }
  if (result.status !== 0) {
    throw new Error(`Failed to resolve ${context}: command exited with code ${result.status ?? "unknown"}`);
  }

  const resolved = result.stdout.trim();
  if (!resolved) throw new Error(`Failed to resolve ${context}: command returned empty output`);
  return resolved;
}

/** Resolve command markers in a configured record without mutating the input. */
export function resolveCommandSecretsRecord(
  values: Record<string, string> | undefined,
  context: (key: string) => string,
): Record<string, string> | undefined {
  if (!values) return undefined;

  return Object.fromEntries(Object.entries(values).map(([key, value]) => [
    key,
    resolveCommandSecret(value, context(key)),
  ]));
}

export function resolveServerUrl(definition: Pick<ServerEntry, "url">, environment: NodeJS.ProcessEnv = process.env): string | undefined {
  if (definition.url == null) return undefined;
  if (typeof definition.url !== "string") {
    throw new Error("MCP server URL must be a string");
  }

  const missing = getMissingEnvVars(definition.url, environment);
  if (missing.length > 0) {
    throw new Error(`Missing environment variable${missing.length === 1 ? "" : "s"} in MCP server URL: ${missing.join(", ")}`);
  }

  const resolved = interpolateEnvVars(definition.url, environment);
  try {
    new URL(resolved);
  } catch (error) {
    throw new Error(`Invalid MCP server URL after environment interpolation: ${resolved}`, { cause: error });
  }
  return resolved;
}

export function resolveConfigPath(value: string | undefined, environment: NodeJS.ProcessEnv = process.env): string | undefined {
  if (value === undefined) return undefined;

  return expandHomePath(interpolateEnvVars(value, environment));
}

/** Expand a leading home-directory marker without interpolating environment variables. */
export function expandHomePath(value: string | undefined): string | undefined {
  if (value === undefined) return undefined;

  const resolved = value;
  if (resolved === "~") return homedir();
  if (resolved.startsWith("~/") || (platform() === "win32" && resolved.startsWith("~\\"))) {
    const suffix = platform() === "win32" ? resolved.slice(2).replace(/[\\/]/g, sep) : resolved.slice(2);
    return join(homedir(), suffix);
  }
  return resolved;
}

export function resolveBearerToken(definition: Pick<ServerEntry, "bearerToken" | "bearerTokenEnv">, environment: NodeJS.ProcessEnv = process.env): string | undefined {
  if (definition.bearerToken !== undefined) {
    return interpolateSecretExpression(definition.bearerToken, environment);
  }
  return definition.bearerTokenEnv ? environment[definition.bearerTokenEnv] : undefined;
}

/** Remove OSC control strings, including payloads that have no terminator. */
export function stripOscSequences(text: string): string {
  let result = "";
  let index = 0;
  while (index < text.length) {
    const isEscOsc = text.charCodeAt(index) === 0x1b && text[index + 1] === "]";
    const isC1Osc = text.charCodeAt(index) === 0x9d;
    if (!isEscOsc && !isC1Osc) {
      result += text[index++];
      continue;
    }

    index += isEscOsc ? 2 : 1;
    while (index < text.length) {
      const code = text.charCodeAt(index++);
      if (code === 0x07 || code === 0x9c) break;
      if (code === 0x1b && text[index] === "\\") {
        index++;
        break;
      }
    }
  }
  return result;
}

export function sanitizeTerminalText(text: string): string {
  return stripOscSequences(text)
    .replace(/(?:\x1b\[[0-?]*[ -/]*[@-~]|\x1b[@-Z\\-_])/g, "")
    .replace(/[\u0000-\u001f\u007f-\u009f]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function formatTerminalError(error: unknown): string {
  const messages: string[] = [];
  const seen = new Set<unknown>();
  const collect = (value: unknown) => {
    if (seen.has(value)) return;
    if ((typeof value === "object" && value !== null) || typeof value === "function") seen.add(value);

    if (value instanceof AggregateError) {
      const countBefore = messages.length;
      for (const nested of value.errors) collect(nested);
      if (value.cause !== undefined) collect(value.cause);
      if (messages.length === countBefore && value.message) messages.push(value.message);
      return;
    }
    if (value instanceof Error) {
      if (value.message) messages.push(value.message);
      if (value.cause !== undefined) collect(value.cause);
      return;
    }
    messages.push(String(value));
  };

  collect(error);
  return sanitizeTerminalText([...new Set(messages)].join(": "));
}

export function truncateAtWord(text: string, target: number): string {
  if (!text || text.length <= target) return text;

  const truncated = text.slice(0, target);
  const lastSpace = truncated.lastIndexOf(" ");

  if (lastSpace > target * 0.6) {
    return truncated.slice(0, lastSpace) + "...";
  }

  return truncated + "...";
}

/** Request `_meta` key that lets MCP servers correlate a call with the Pi tool call that made it. */
export const TOOL_CALL_ID_REQUEST_META_KEY = "pi-mcp-adapter/toolCallId";

export function withToolCallIdMeta(
  meta: Record<string, unknown> | undefined,
  toolCallId: string | undefined,
): Record<string, unknown> | undefined {
  if (!toolCallId) return meta;
  return { ...meta, [TOOL_CALL_ID_REQUEST_META_KEY]: toolCallId };
}

export function normalizeDirectToolInputSchema(schema: unknown): Record<string, unknown> {
  const inputSchema = schema && typeof schema === "object" && !Array.isArray(schema)
    ? schema as Record<string, unknown>
    : { type: "object", properties: {} };
  const { $schema, additionalProperties, ...normalized } = inputSchema;
  return normalized;
}

export function normalizeToolArguments(
  value: unknown,
  context = "tool arguments",
): Record<string, unknown> {
  if (value === undefined || value === null || value === "") return {};

  if (typeof value === "string") {
    const trimmed = value.trim();
    if (trimmed === "") return {};
    let parsed: unknown;
    try {
      parsed = JSON.parse(trimmed);
    } catch (error) {
      throw new Error(
        `${context}: invalid args JSON (${error instanceof SyntaxError ? error.message : String(error)}); ` +
        `pass args as a JSON object, or as a valid JSON string encoding one`,
        { cause: error },
      );
    }
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      throw new Error(
        `${context}: expected a JSON object, got ${Array.isArray(parsed) ? "array" : typeof parsed}`,
      );
    }
    return parsed as Record<string, unknown>;
  }

  if (typeof value !== "object" || Array.isArray(value)) {
    throw new Error(
      `${context}: expected a JSON object, got ${Array.isArray(value) ? "array" : typeof value}`,
    );
  }

  assertJsonSerializable(value, context);
  try {
    return JSON.parse(JSON.stringify(value)) as Record<string, unknown>;
  } catch (error) {
    throw new Error(
      `${context}: value is not JSON-serializable: ${error instanceof Error ? error.message : String(error)}`,
      { cause: error },
    );
  }
}

function assertJsonSerializable(value: unknown, context: string, path = ""): void {
  if (value === null) return;
  if (typeof value === "string" || typeof value === "boolean") return;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error(`${context}: value at ${path || "root"} is not a finite number`);
    return;
  }
  if (Array.isArray(value)) {
    for (const [index, item] of value.entries()) assertJsonSerializable(item, context, `${path}[${index}]`);
    return;
  }
  if (typeof value === "object") {
    if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new Error(`${context}: value at ${path || "root"} is not a plain JSON object`);
    }
    if (Object.getOwnPropertySymbols(value).length > 0) {
      throw new Error(`${context}: value at ${path || "root"} has symbol keys`);
    }
    for (const [key, item] of Object.entries(value)) {
      assertJsonSerializable(item, context, path ? `${path}.${key}` : key);
    }
    return;
  }
  throw new Error(`${context}: value at ${path || "root"} is not JSON-serializable`);
}

export function formatAuthRequiredMessage(
  config: Pick<McpConfig, "settings" | "mcpServers">,
  serverName: string,
  defaultMessage: string,
): string {
  const auth = config.mcpServers[serverName]?.auth;
  if (typeof auth === "object") return providerSignInMessage(serverName, auth.provider);
  const template = config.settings?.authRequiredMessage;
  return template ? template.replaceAll("${server}", serverName) : defaultMessage;
}

/** Servers with `auth.provider` sign in through Pi, never through MCP OAuth. */
export function providerSignInMessage(serverName: string, provider: string): string {
  return `MCP server "${serverName}" needs sign-in. Run /login ${provider}, then /mcp-adapter reconnect ${serverName}.`;
}

/** Why a server must not receive its `auth.provider` token at `url`, or undefined when it may. */
export function providerAuthUrlError(url: string): string | undefined {
  const parsed = URL.canParse(url) ? new URL(url) : undefined;
  if (parsed?.protocol === "https:") return undefined;
  if (parsed?.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(parsed.hostname)) return undefined;
  return "auth.provider requires an https URL, or http on localhost, 127.0.0.1, or [::1]";
}

export function formatMcpStatus(config: Pick<McpConfig, "settings">, message: string): string | undefined {
  if (config.settings?.mcpFooterStatus === "off") return undefined;
  return `${config.settings?.showStatusIcon === false ? "MCP: " : "🔌 MCP: "}${message}`;
}

export function formatMcpFooterStatus(
  config: Pick<McpConfig, "settings">,
  enabledCount: number,
  disabledCount: number,
  connectedCount: number,
): string | undefined {
  if (enabledCount + disabledCount === 0 || config.settings?.mcpFooterStatus === "off") return undefined;
  const footerStatus = config.settings?.mcpFooterStatus ?? "full";
  if (footerStatus === "compact") return `MCP ${connectedCount}/${enabledCount}`;

  let status = `${enabledCount} ${enabledCount === 1 ? "server" : "servers"} enabled`;
  if (connectedCount > 0) status += ` (${connectedCount} connected)`;
  if (disabledCount > 0) status += ` (${disabledCount} disabled)`;
  return formatMcpStatus(config, status);
}

/**
 * Extract the adapter-owned UI stream mode from tool metadata.
 */
export function extractToolUiStreamMode(toolMeta: Record<string, unknown> | undefined): "eager" | "stream-first" | undefined {
  const uiMeta = toolMeta?.ui;
  if (!uiMeta || typeof uiMeta !== "object") return undefined;
  const streamMode = (uiMeta as Record<string, unknown>)["pi-mcp-adapter.streamMode"];
  if (streamMode === "eager" || streamMode === "stream-first") {
    return streamMode;
  }
  return undefined;
}

/**
 * Keep only the spec tool annotations with the right types. Server and cache
 * input is untrusted, so a malformed field is dropped instead of failing the tool list.
 */
export function extractToolAnnotations(annotations: unknown): McpToolAnnotations | undefined {
  if (!annotations || typeof annotations !== "object") return undefined;
  const source = annotations as Record<string, unknown>;
  const kept: McpToolAnnotations = {};
  if (typeof source.title === "string") kept.title = source.title;
  for (const key of ["readOnlyHint", "destructiveHint", "idempotentHint", "openWorldHint"] as const) {
    if (typeof source[key] === "boolean") kept[key] = source[key];
  }
  return Object.keys(kept).length > 0 ? kept : undefined;
}
